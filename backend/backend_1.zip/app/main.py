"""
AI Social Manager - Backend v0.3
Fully Integrated:
- Supabase Auth (JWT verification)
- AI Adapter w/ OpenAI -> Gemini failover
- Instagram OAuth + Analytics
- YouTube OAuth + Upload + Analytics
- Encrypted user API keys (OpenAI/Gemini)
- CORS + Database Setup

NOTE: Replace relative imports (“from .x”) with your structure if needed.
"""

import os
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from cryptography.fernet import Fernet

# Core backend modules
from .auth_supabase import verify_supabase_jwt
from .db import db
from .ai_adapter import generate_text

# Social integrations (routers)
from .youtub.auth_youtube import router as youtube_auth_router
from .youtube.youtube_upload import router as youtube_upload_router
from .youtube.youtube_api import router as youtube_api_router

from .instagram.auth_instagram import router as instagram_auth_router
from .instagram.instagram_api import router as instagram_api_router


# -----------------------------
# FASTAPI INIT
# -----------------------------

app = FastAPI(title="AI Social Manager - Backend v0.3")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # adjust in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# -----------------------------
# FERNET ENCRYPTION
# -----------------------------

FERNET_KEY = os.getenv("FERNET_KEY")
if not FERNET_KEY:
    raise RuntimeError("FERNET_KEY must be set in environment")
fernet = Fernet(FERNET_KEY.encode())


# -----------------------------
# Pydantic Models
# -----------------------------

class StoreAIKeyIn(BaseModel):
    provider: str     # "openai" or "gemini"
    api_key: str

class GenerateIn(BaseModel):
    prompt: str
    model: str = "gpt-4o-mini"


# -----------------------------
# EVENTS: DB CONNECT/DISCONNECT
# -----------------------------

@app.on_event("startup")
async def startup():
    await db.connect()

@app.on_event("shutdown")
async def shutdown():
    await db.disconnect()


# -----------------------------
# HEALTH
# -----------------------------

@app.get("/health")
async def health():
    return {"status": "ok"}


# -----------------------------
# STORE AI KEYS (encrypted)
# -----------------------------

@app.post("/user/ai-key")
async def store_ai_key(payload: StoreAIKeyIn, jwt_payload=Depends(verify_supabase_jwt)):
    user_id = jwt_payload.get("sub")

    if payload.provider.lower() not in ("openai", "gemini"):
        raise HTTPException(status_code=400, detail="Provider must be openai or gemini")

    encrypted = fernet.encrypt(payload.api_key.encode()).decode()

    query = """
        INSERT INTO user_api_keys (user_id, provider, encrypted_api_key)
        VALUES (:uid, :prov, :key)
        ON CONFLICT (user_id, provider)
        DO UPDATE SET encrypted_api_key = EXCLUDED.encrypted_api_key, created_at = NOW()
    """

    await db.execute(query, {"uid": user_id, "prov": payload.provider.lower(), "key": encrypted})
    return {"status": "ok"}


# -----------------------------
# FETCH & DECRYPT KEY
# -----------------------------

async def get_key(user_id: str, provider: str):
    row = await db.fetch_one(
        "SELECT encrypted_api_key FROM user_api_keys WHERE user_id = :uid AND provider = :p",
        {"uid": user_id, "p": provider}
    )
    if not row:
        return None

    try:
        return fernet.decrypt(row["encrypted_api_key"].encode()).decode()
    except:
        return None


# -----------------------------
# AI GENERATION ENDPOINT (OpenAI → Gemini failover)
# -----------------------------

@app.post("/ai/generate")
async def ai_generate(payload: GenerateIn, jwt_payload=Depends(verify_supabase_jwt)):
    user_id = jwt_payload.get("sub")

    openai_key = await get_key(user_id, "openai")
    gemini_key = await get_key(user_id, "gemini")

    if not openai_key and not gemini_key:
        raise HTTPException(400, "User has no AI keys stored")

    try:
        result = await generate_text(
            openai_key=openai_key or "",
            gemini_key=gemini_key or "",
            prompt=payload.prompt,
            model=payload.model
        )
    except Exception as e:
        raise HTTPException(502, f"Both AI providers failed: {e}")

    return {"result": result}


# -----------------------------
# SCHEDULING POSTS
# -----------------------------

@app.post("/schedule")
async def schedule_post(data: dict, jwt_payload=Depends(verify_supabase_jwt)):
    user_id = jwt_payload.get("sub")

    content = data.get("content")
    social_id = data.get("social_account_id")
    scheduled_at = data.get("scheduled_at")

    if not content:
        raise HTTPException(400, "content missing")

    query = """
        INSERT INTO scheduled_posts (user_id, social_account_id, content, scheduled_at)
        VALUES (:uid, :sid, :content, :sched)
    """

    await db.execute(
        query,
        {"uid": user_id, "sid": social_id, "content": content, "sched": scheduled_at}
    )

    return {"status": "scheduled"}


# -----------------------------
# ROUTER INTEGRATION
# -----------------------------

app.include_router(youtube_auth_router, prefix="/auth/youtube", tags=["YouTube OAuth"])
app.include_router(youtube_upload_router, prefix="/youtube", tags=["YouTube Upload"])
app.include_router(youtube_api_router, prefix="/youtube", tags=["YouTube API"])

app.include_router(instagram_auth_router, prefix="/auth/instagram", tags=["Instagram OAuth"])
app.include_router(instagram_api_router, prefix="/instagram", tags=["Instagram API"])

