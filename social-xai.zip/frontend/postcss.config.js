export default {
  plugins: {
    '@tailwindcss/postcss': {}, // Updated package name
    autoprefixer: {},
  },
}